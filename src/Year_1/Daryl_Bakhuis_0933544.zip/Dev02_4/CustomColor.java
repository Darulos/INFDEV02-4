package Year_1.Dev02_4;


public enum CustomColor {
    WHITE,
    BLACK,
    BLUE
}
