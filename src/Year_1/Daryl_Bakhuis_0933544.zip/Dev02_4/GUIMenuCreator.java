package Year_1.Dev02_4;

// Describes a class with a factory method for creating menu screens

public abstract class GUIMenuCreator {
    //TODO: ADD MISSING CODE HERE
    public abstract GUIManager instantiate(String option, Runnable exitAction);
}
