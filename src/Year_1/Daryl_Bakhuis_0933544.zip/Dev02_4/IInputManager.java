package Year_1.Dev02_4;


// This interface should be implemented by all clickable GUI elements

public interface IInputManager {
    //TODO: ADD MISSING CODE HERE
    IOption<Point> click();
}
