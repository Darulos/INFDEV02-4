package Year_1.Dev02_4;

// Any drawable object should implement this interface
interface IDrawable {

    void draw(IDrawVisitor visitor);
}
